export interface Quote {
    id: String;
    person: String;
    text: String;
}